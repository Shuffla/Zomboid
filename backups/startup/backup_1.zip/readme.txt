Backup time: 2024-10-20 at 19:40:04 CEST
ServerName: Sons_of_Pyro
Current server version:41.78
Current world version:195
World version in this backup is:195