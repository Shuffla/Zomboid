{
    items = {
    },
    recipes = {
    },
}