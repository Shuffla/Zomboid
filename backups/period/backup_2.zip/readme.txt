Backup time: 2024-07-29 at 19:59:41 CEST
ServerName: Sons_Of_Pyro
Current server version:41.78
Current world version:195
World version in this backup is:195